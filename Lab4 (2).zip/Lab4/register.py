import sqlite3

class DatabaseConnection:
    def __init__(self, db_name='registration.db'):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE
        )
        ''')
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS subjects (
            sub_id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_name TEXT NOT NULL
        )
        ''')
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            sub_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            FOREIGN KEY (sub_id) REFERENCES subjects (sub_id)
        )
        ''')

    def commit(self):
        self.conn.commit()

    def close(self):
        self.conn.close()


class User:
    def __init__(self, db):
        self.db = db

    def register_user(self, name, email):
        self.db.cursor.execute('INSERT INTO users (name, email) VALUES (?, ?)', (name, email))
        self.db.commit()
        return self.db.cursor.lastrowid

    def display_users(self):
        self.db.cursor.execute('SELECT user_id, name, email FROM users')
        return self.db.cursor.fetchall()


class Subject:
    def __init__(self, db):
        self.db = db

    def register_subject(self, subject_name):
        self.db.cursor.execute('INSERT INTO subjects (subject_name) VALUES (?)', (subject_name,))
        self.db.commit()
        return self.db.cursor.lastrowid

    def display_subjects(self):
        self.db.cursor.execute('SELECT sub_id, subject_name FROM subjects')
        return self.db.cursor.fetchall()


class Registration:
    def __init__(self, db):
        self.db = db

    def register_user_to_subject(self, user_id, sub_id):
        self.db.cursor.execute('INSERT INTO registrations (user_id, sub_id) VALUES (?, ?)', (user_id, sub_id))
        self.db.commit()

    def fetch_all_users_and_subjects(self):
        self.db.cursor.execute('''
        SELECT users.name, users.email, subjects.subject_name 
        FROM registrations
        JOIN users ON registrations.user_id = users.user_id
        JOIN subjects ON registrations.sub_id = subjects.sub_id
        ''')
        return self.db.cursor.fetchall()


# Function to prompt user input
def get_user_input(prompt, choices):
    print(prompt)
    for idx, choice in enumerate(choices, 1):
        print(f"{idx}. {choice}")
    selection = int(input("Select an option: "))
    return choices[selection - 1]


def main():
    db = DatabaseConnection()

    user = User(db)
    subject = Subject(db)
    registration = Registration(db)

    # Main menu
    while True:
        print("\n--- Registration System ---")
        print("1. Register a user")
        print("2. Register a subject")
        print("3. Register a user for a subject")
        print("4. View all registrations")
        print("5. Exit")
        
        choice = input("Choose an option: ")

        if choice == "1":
            # Register a user
            name = input("Enter user name: ")
            email = input("Enter user email: ")
            user.register_user(name, email)
            print("User registered successfully!")

        elif choice == "2":
            # Register a subject
            subject_name = input("Enter subject name: ")
            subject.register_subject(subject_name)
            print("Subject registered successfully!")

        elif choice == "3":
            # Register a user for a subject
            users = user.display_users()
            subjects = subject.display_subjects()

            if not users or not subjects:
                print("No users or subjects available. Please add some first.")
                continue

            selected_user = get_user_input("Select a user to register:", [f"{u[0]} - {u[1]}" for u in users])
            selected_subject = get_user_input("Select a subject to register:", [s[1] for s in subjects])

            # Extract user_id and sub_id from the selection
            user_id = int(selected_user.split(" ")[0])  # Extract user_id from the selection
            sub_id = next(s[0] for s in subjects if s[1] == selected_subject)  # Extract sub_id from subject name

            registration.register_user_to_subject(user_id, sub_id)
            print("Registration successful!")

        elif choice == "4":
            # View all registrations
            for row in registration.fetch_all_users_and_subjects():
                print(row)

        elif choice == "5":
            print("Exiting...")
            break

        else:
            print("Invalid option, please try again.")

    db.close()


if __name__ == "__main__":
    main()
